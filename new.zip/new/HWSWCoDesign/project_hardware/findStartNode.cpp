#include <iostream>
using namespace std;

int prc_findStartNode();

int main(int argc, char* argv[]){
    cout << prc_findStartNode();
    return 0;
}

int prc_findStartNode() {
    int cNode = 0b000000011;
    return cNode;
}