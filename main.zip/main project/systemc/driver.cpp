#include "driver.h"

void driver::prc_driver(){
    n = 30, W = 20;

    for(int i=0; i<31; i++){
        ready = true;
        wait(1, SC_NS);

        ready = false;
        wait(9, SC_NS);
    }
}